#ifndef __NODE_H__
#define __NODE_H__
#include <iostream>

class Node{
public:
    int data;
    Node *next;
};

#endif
