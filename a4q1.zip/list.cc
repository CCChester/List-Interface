#include <iostream>
#include "list.h"
#include <iostream>

/*********** List **********
    Purpose: implement the destructor.
 ***********************************/

List::~List(){
}
